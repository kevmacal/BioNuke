using UnityEngine;

public class PlayerController : MonoBehaviour
{

    [SerializeField]
    float speed;
    
    private Vector2 direction = Vector2.right;
    float velX, velY;
    public Rigidbody2D playerRigidbody { get; private set; }

    public KeyCode inputUp = KeyCode.W;
    public KeyCode inputDown = KeyCode.S;
    public KeyCode inputLeft = KeyCode.A;
    public KeyCode inputRight = KeyCode.D;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerRigidbody = GetComponent<Rigidbody2D>();
    }

    private void Awake()
    {
        playerRigidbody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(inputUp))
        {
            SetDirection(Vector2.up);
        }
        else if (Input.GetKey(inputDown))
        {
            SetDirection(Vector2.down);
        }
        else if (Input.GetKey(inputLeft))
        {
            SetDirection(Vector2.left);
        }
        else if (Input.GetKey(inputRight))
        {
            SetDirection(Vector2.right);
        }
        else
        {
            SetDirection(Vector2.zero);
        }
    }

    private void FixedUpdate()
    {
        Vector2 posTmp = playerRigidbody.position;
        Vector2 translation = direction * speed * Time.fixedDeltaTime;

        playerRigidbody.MovePosition(posTmp + translation);
    }

    void SetDirection(Vector2 newDirection)
    {
        direction = newDirection;
    }
}
